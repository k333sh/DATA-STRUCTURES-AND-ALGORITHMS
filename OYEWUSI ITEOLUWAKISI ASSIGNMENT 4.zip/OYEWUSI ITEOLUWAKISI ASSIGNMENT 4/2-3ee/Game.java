/* OYEWUSI ITEOLUWAKISI
   ASSIGNMENT 4 T3 TREE IMPLEMENTATION
 * 
*/
import java.io.File;
import java.util.Scanner;
import java.util.Random; //random importer

public class Game {
    public Player playerA;
    public Player playerB;
    private int rounds;
    private Random random = new Random();// Random choice element

    class Player {
        private String name;// player name
        private GameTree tree;// player tree using gameTree interface
        private int score;// player score

        // Player Constructor
        public Player(String name, GameTree tree) {
            this.name = name;
            this.tree = tree;
            this.score = 0;
        }

        public String getName() {
            return name;// player name
        }

        public GameTree getTree() {
            return tree;// get Player tree
        }

        public int getScore() {
            return score;// player score
        }

        public void addScore(int points) {
            this.score += points;// increase score by points
        }

        private GameTree initializeTreeFromFile(String fileName) throws Exception {
            Scanner fileScanner = new Scanner(new File(fileName));// read from file
            String treeType = fileScanner.nextLine().trim();// trim off spaces
            GameTree tree;// initialize tree

            // Initialize based on tree type
            if (treeType.equalsIgnoreCase("TwoThreeTree")) {
                tree = new TwoThreeTree();// Implement TwoThreeTree class
            } else {
                throw new IllegalArgumentException("Invalid tree type in file: " + fileName);
            }

            // Add words to the tree
            while (fileScanner.hasNext()) {
                String word = fileScanner.next().trim().toLowerCase();
                tree.addWord(word);// addword to our tree
            }

            fileScanner.close();// close scanner
            return tree;
        }

        // set up game for user to see
        public void setupGame(String fileA, String fileB) throws Exception {
            // Initialize players and trees
            GameTree treeA = initializeTreeFromFile(fileA);
            GameTree treeB = initializeTreeFromFile(fileB);

            playerA = new Player("Player A", treeA);
            playerB = new Player("Player B", treeB);

            // Decide number of rounds (2–5)
            rounds = random.nextInt(4) + 2;

            // Randomly choose turn order
            System.out.println("Flipping a coin to decide who starts...");
            if (random.nextBoolean()) {
                System.out.println(playerA.getName() + " will go first.");
            } else {
                System.out.println(playerB.getName() + " will go first.");
                // Swap player turns
                Player temp = playerA;
                playerA = playerB;
                playerB = temp;
            }
        }

        private void performAttack(Player attacker, Player defender) {
            Scanner scanner = new Scanner(System.in);
            System.out.println(attacker.getName() + ", What word are we attacking:");
            attacker.getTree().print();// print attackers tree
            String word = scanner.nextLine().trim();// Get our word in

            if (attacker.getTree().containsWord(word)) {
                int attackerFreq = attacker.getTree().getFrequency(word);// frequency of word to be attacked
                int defenderFreq = defender.getTree().getFrequency(word);// as above for defended word

                if (attackerFreq > defenderFreq) {
                    System.out.println("Attack successful! Scored " + attackerFreq + " points.");
                    attacker.addScore(attackerFreq);// add point from attack to score
                    // Mark the word as used
                    attacker.getTree().addWord(word);
                } else {
                    System.out.println("Attack failed. No points scored.");
                }
            } else {
                System.out.println("Invalid word! Choose again."); // word not pressnt
            }
        }

        private void performDefend(Player defender) {
            Scanner scanner = new Scanner(System.in);
            System.out.println(defender.getName() + ", select a word to defend:");
            defender.getTree().print();
            String word = scanner.nextLine().trim().toLowerCase();

            if (defender.getTree().containsWord(word)) {
                int frequency = defender.getTree().getFrequency(word); // word freq
                defender.getTree().addWord(word);
                System.out.println("WHAT A SAVE! Frequency of " + word + " is now " + (frequency * 2));
            } else {
                System.out.println("CANNOT DEFEND WORDS THAT ARE NOT HERE "); // word not present
            }
        }

        private void performSwap(Player player) {
            Scanner scanner = new Scanner(System.in);
            System.out.println(player.getName() + ", select two words to swap:");
            player.getTree().print();
            System.out.print("Word 1: ");
            String word1 = scanner.nextLine().trim();
            System.out.print("Word 2: ");
            String word2 = scanner.nextLine().trim();

            if (player.getTree().containsWord(word1) && player.getTree().containsWord(word2)) {
                // GEt frequencies if both words are present
                int freq1 = player.getTree().getFrequency(word1);
                int freq2 = player.getTree().getFrequency(word2);
                //introduce temporary variable then swap 
                int temp = freq1;
                freq1 = freq2;
                freq2 = temp;

                player.getTree().setFrequency(word1,freq2);
                player.getTree().setFrequency(word2, freq1);

                System.out.println("Swap successful! " + word1 + " and " + word2 + " frequencies swapped.");
            } else {
                System.out.println("Invalid words! Choose again."); //cant swap that word choice if not present
            }
        }

        public void playGame() {
            for (int i = 1; i <= rounds; i++) {
                System.out.println("\n--- Round " + i + " ---");
                // take turns giving ecach person a turn giving each person a chance to go 1
                playTurn(playerA, playerB);
                playTurn(playerB, playerA);

                // Print scores and trees after each round
                System.out.println("\nScores after Round " + i + ":");
                System.out.println(playerA.getName() + ": " + playerA.getScore());
                System.out.println(playerB.getName() + ": " + playerB.getScore());
                System.out.println("\nPlayer A's Tree:");
                playerA.getTree().printTree();
                System.out.println("\nPlayer B's Tree:");
                playerB.getTree().printTree();
            }

            // Determine winner
            if (playerA.getScore() > playerB.getScore()) {
                System.out.println("\n" + playerA.getName() + " wins!"); // This player WIns
            } else if (playerB.getScore() > playerA.getScore()) {
                System.out.println("\n" + playerB.getName() + " wins!");
            } else {
                System.out.println("\nIt's a tie!"); // Eaual scores
            }
        }

        private void playTurn(Player currentPlayer, Player opponent) {
            System.out.println("\n" + currentPlayer.getName() + "'s turn!"); // Player name

            // User options
            System.out.println("Choose an action:");
            System.out.println("1. Attack");
            System.out.println("2. Defend");
            System.out.println("3. Swap");

            // Read and validate input
            Scanner scanner = new Scanner(System.in);
            int choice = -1; // choice starts at a non iputable digit
            while (choice < 1 || choice > 3) {
                System.out.print("Enter your choice from  (1-3): ");
                if (scanner.hasNextInt()) {
                    choice = scanner.nextInt(); /// scan choice in
                } else {
                    scanner.next(); // Clear invalid input
                    System.out.println("Invalid input! Please enter a NUMBER between 1 and 3.");
                }
            }

            // Execute the chosen action
            if (choice == 1) {
                performAttack(currentPlayer, opponent); // Attack
            } else if (choice == 2) {
                performDefend(currentPlayer); // Defend
            } else if (choice == 3) {
                performSwap(currentPlayer); // Swap
            } else {
                System.out.println("Unexpected choice! This shouldn't happen."); // not a valid choice
            }
        }

    }
}