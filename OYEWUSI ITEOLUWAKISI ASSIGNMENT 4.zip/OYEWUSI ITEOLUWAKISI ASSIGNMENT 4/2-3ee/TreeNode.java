public class TreeNode {

    String[] words; // Stores up to two words
    int[] frequencies; // Frequency of each word
    TreeNode[] children; // Child pointer
    TreeNode parent; //parent pointer

    public TreeNode(){
        this.words = new String[2];
        this.frequencies = new int[2];
        this.children = new TreeNode[4];
        this.parent = null;
    }
  
    //second constructor that accepts word input to ease insertion
    public TreeNode(String word){
      this(); //calls our default constructor
      this.words[0] = word; //set our word to be the one constructed
      this.frequencies[0] = 1 ; //hence give our selves a frequency of amount 1
    }
    
    
}
