public class TwoThreeTree implements GameTree {

    private TreeNode root; // Root of the tree
    private int size; // Number of words in the tree
    private int height; // Height of the tree

    // Constructor to initialize an empty tree
    public TwoThreeTree() {
        this.root = null; // Our Tree starts empty
        this.size = 0; // No words yet
        this.height = 0; // empty tree height
    }

    public void addWord(String word) {
        TreeNode inserted = new TreeNode(word);
        if (root == null) {
            root = inserted;
        } else {
            TreeNode curr = root;
            // traverse to find insertion point
            curr = NodeToInsert(curr, word);
            // Is our Node full at this insertion point
            if (curr.words[0] == null || curr.words[1] == null) {
                insertWord(curr, word);
            } else {
                splitNode(curr, word);
            }
        }
    }

    private void splitNode(TreeNode curr, String word) {
        // Check if the word already exists and isnt null either in the first or second
        // stored word
        if (curr.words[0] != null && word.equals(curr.words[0])) {
            curr.frequencies[0]++; // increase its frequency
        } else if (curr.words[1] != null && word.equals(curr.words[1])) {
            curr.frequencies[1]++; // increase its frequency

        } else {
            String midwrd = ""; // middle word string for split operations
            TreeNode newChild = new TreeNode();

            // Is our inserterted Word smaller than the smallest word
            if (word.compareToIgnoreCase(curr.words[0]) < 0) {
                // swap position with wrd[0]
                midwrd = curr.words[0];
                curr.words[0] = word;
            } else if (word.compareToIgnoreCase(curr.words[1]) < 0) {
                midwrd = word; // We know it to be bigger than whatever is at position 0 but smaller than
                               // position 1 , so it becomes our middleWord
            } else {
                // its the biggest word
                midwrd = curr.words[1];// swap positions with the biggest set Word
                curr.words[1] = word;
            }

            // Create new child for the right side
            newChild.words[0] = curr.words[1]; // adding right sided child
            curr.words[1] = null; // Clear the right word slot

            // Push the middle word up to the parent
            if (curr.parent == null) {
                // If the current node is the root create a new root
                TreeNode newRoot = new TreeNode();
                newRoot.words[0] = midwrd; // set the middlw up to the newRoot
                newRoot.children[0] = curr; // leftChild is the smallest so it goes first
                newRoot.children[1] = newChild;// The biggest word is our rightchild
                root = newRoot; // New root for the tree
                curr.parent = newRoot;// connect ur child to its parent the new root
            } else {
                LinkChildToParent(curr, midwrd, newChild);// Else handle the split by pushing up
            }
        }
    }

    private void insertWord(TreeNode curr, String word) {
        if (curr.words[0] == null) {
            curr.words[0] = word; // left child open insert there
        } else if (word.compareToIgnoreCase(curr.words[0]) < 0) { // right child open but word is smaller than our word
            curr.words[1] = curr.words[0];
            curr.words[0] = word;
        } else {
            curr.words[1] = word; // right chil open and our word is bigger
        }
    }

    private void LinkChildToParent(TreeNode curr, String midwrd, TreeNode newChild) {
        TreeNode parent = curr.parent;

        int insertIndex = 0;
        // Loop through our parents length till we fall off the tree or the middleWord
        // ends up smaller than the parent WHICH IS WRONG so stop
        while (insertIndex < parent.words.length && parent.words[insertIndex] != null
                && midwrd.compareToIgnoreCase(parent.words[insertIndex]) > 0) {
            insertIndex++;
        }

        for (int j = parent.words.length - 1; j > insertIndex; j--) {
            parent.words[j] = parent.words[j - 1]; // shift our words back one for midd to the inserted at first
            parent.children[j + 1] = parent.children[j];
        }

        parent.words[insertIndex] = midwrd; // that space created is for our midwrd insertion
        parent.children[insertIndex + 1] = newChild; // newChild bigger push to the side of newWrd
        newChild.parent = parent; // set child to parent

        // Check if we need to split parents , if its full
        if (parent.words[1] != null) {
            curr = parent;
            midwrd = parent.words[1]; // Promote the middle word
            parent.words[1] = null; // Clear the middle word after promotion

            // Propagate the middle word to the parent
            curr.parent.words[0] = midwrd;

            if (curr.parent == null) {
                // Do steps from when it was not full
                TreeNode newRoot = new TreeNode();
                newRoot.words[0] = midwrd;
                newRoot.children[0] = curr;
                root = newRoot;
                curr.parent = newRoot;
            } else {
                LinkChildToParent(curr, midwrd, newChild); // recursively call to keep this going till our condition is
                                                           // met
            }
        }

    }

    // Helps us find where the ChildNode we are to look at is
    private TreeNode NodeToInsert(TreeNode current, String wordTI) {

        int i = 0;
        while (current.children[0] != null) { // Loop while we still have leaves
            Boolean positionFound = false; // initialize checking boolean
            // Find the correct child to look through
            // traverse till we hit a word where our wordToInsert is less than the word we
            // are on
            for (i = 0; i < current.words.length && current.words[i] != null && !positionFound; i++) {
                if (wordTI.compareToIgnoreCase(current.words[i]) < 0) {
                    // Move to the child Node
                    positionFound = true;
                }
            }

            if (positionFound) {
                current = current.children[i - 1]; // The position we found is at i , then minus one since our for loop
                                                   // will
                // rise again
            } else {
                current = current.children[i];// This means that its position wasnt found since its greater than every
                                              // word
                                              // hence going to be inserted at the right most Node
            }
        }
        return current;
    }

    public boolean containsWord(String word) {
        boolean WordHere = false;

        TreeNode curr = this.root;

        while (curr != null && !WordHere) {
            boolean movedToAChild = false; // indicator of whether we have moved down to a child n=treenode
            for (int i = 0; i < curr.words.length && curr.words[i] != null; i++) {
                if (word.compareToIgnoreCase(curr.words[i]) == 0) { // If we find it at the first node we check
                    WordHere = true;
                } else if (word.compareToIgnoreCase(curr.words[i]) < 0) { // If our word is bigger than the current node
                                                                          // word
                    curr = curr.children[i]; // move to the left or middle child (OUR WORD IS SMALLER THAN WHATEVER WORD
                                             // WAS AT THE CURRENT NODE)
                    movedToAChild = true;
                } else if (i + 1 < curr.words.length - 1 && curr.words[i + 1] == null
                        && word.compareToIgnoreCase(curr.words[i + 1]) > 0) { // check if we in between the right most
                                                                              // child but > than the leftmost
                    curr = curr.children[i + 1];// move to that point in the current trees child
                    movedToAChild = true;
                }
            }
            // If we didn't move to a child, we should check the rightmost child
            if (!movedToAChild) {
                // Check if there are any present words in this curr treeNode
                if (curr.words.length > 0) {
                    // attributing the right most to be the length of words which ennds up being
                    // A[n-1]
                    curr = curr.children[curr.words.length - 1]; // Set current to be our last Child
                } else {
                    curr = null; // No children to move to so current is now null and we can stop traversing
                }
            }
        }
        return WordHere; // return our boolean
    }

    public int getFrequency(String word) {
        if (!containsWord(word)) {
            return 0;
        }
        int freq = 0;
        TreeNode curr = this.root;
        while (curr != null) {
            boolean movedToAChild = false; // indicator of whether we have moved down to a child n=treenode
            for (int i = 0; i < curr.words.length && curr.words[i] != null && !movedToAChild; i++) {
                if (word.compareToIgnoreCase(curr.words[i]) == 0) { // If we find it at the first node we check
                    return curr.frequencies[i];
                } else if (word.compareToIgnoreCase(curr.words[i]) < 0) { // If our word is bigger than the current node
                                                                          // word
                    curr = curr.children[i]; // move to the left or middle child (OUR WORD IS SMALLER THAN WHATEVER WORD
                                             // WAS AT THE CURRENT NODE)
                    movedToAChild = true;
                } else if (i + 1 < curr.words.length - 1 && curr.words[i + 1] == null
                        && word.compareToIgnoreCase(curr.words[i + 1]) > 0) { // check if we in between the right most
                    // child but > than the leftmost
                    curr = curr.children[i + 1];// move to that point in the current trees child
                    movedToAChild = true;
                }
            }
            // If we didn't move to a child, we should check the rightmost child
            if (!movedToAChild) {
                // Check if there are any present words in this curr treeNode
                if (curr.words.length > 0) {
                    // attributing the right most to be the length of words which ennds up being
                    // A[n-1]
                    curr = curr.children[curr.words.length - 1]; // Set current to be our last Child
                } else {
                    curr = null; // No children to move to so current is now null and we can stop traversing
                }
            }
        }
        return freq;
    }

    public void print() {
        printLexographically(this.root);
    }

    public void printLexographically(TreeNode curr) {
        if (curr == null) {
            System.out.println("NOTHING TO PRINT"); // base case if our curr is eventually null
        }

        if (curr.children[0] != null) {
            printLexographically(curr.children[0]); // If the lft child exists run recursively
        }

        for (int i = 0; i < curr.words.length; i++) {
            // Print the words at current TreedNode if not null
            if (curr.words[i] != null) {
                System.out.print(" " + curr.words[i] + "(" + curr.frequencies[i] + ")" + "");
            }

            // editing comma placement using checks for if this is the last word and know
            // not to put the comma
            if (i < curr.words.length - 1) {
                System.out.print(",");
            }

        }

        if (curr.children[1] != null) {
            printLexographically(curr.children[1]); // If the middle child exists run recursively
        }

        if (curr.children[2] != null) {
            printLexographically(curr.children[2]); // If the right child exists run recursively

        }
    }

    public int height() {
        return haight(this.root); //compute Height
    }

    private int haight(TreeNode curr) {
        // empty = 0 as stated
        if (curr == null) {
            return 0;
        }
        int maxHeight = -1; // set our empty height
        // looop through all the kids
        for (int i = 0; i < curr.children.length; i++) {
            // If not null
            if (curr.children[i] != null) {
                maxHeight = Math.max(maxHeight, haight(curr.children[i])); // height is the highest number beteween
                                                                           // currrent height and height at point whivh
                                                                           // current child treeNode is
            }
        }
        return maxHeight + 1; // return our height being +1 to account for the edges
    }

    public TreeNode getRoot() {
        return root;
    }

    public void compare(GameTree otherTree) {
        if (otherTree == null) {
            System.out.println("INVALID COMP , OTHER TREE IS NULL");
        }
        if (otherTree.getClass() != this.getClass()) {
            System.out.println("INCOMPATIBLE DATA TYPES");
        }
        if (this == otherTree) {
            System.out.println("IDENTICAL TREES");
        }
        System.out.println("Common words:");
        commonWordFinder(this.root, otherTree);

        System.out.println("\nWords unique to this tree:");
        findUniqueWords(this.root, otherTree);

        System.out.println("\nWords unique to other tree:");
        findUniqueWords(otherTree.getRoot(), this);

    }

    // Common word helper function
    private boolean commonWordFinder(TreeNode curr, GameTree otherTree) {
        boolean cWF = false;// did we find a common one
        // We are null,return false MORE OR LESS LIKE
        try {
            
        if (curr == null) {
            System.out.println("NOTHING TO FIND");
        } else {
            for (int i = 0; i < curr.words.length && curr.words[i] != null; i++) {
                String word = curr.words[i];
                if (otherTree != null && otherTree.containsWord(word)) { // did we see a match in our other tree
                    cWF = true;
                    System.out.print(word + " ");// print commonWrd and its frequency
                }
            }
            // Do it for every other non null children of our initial TreeNode By Calling
            // recursively Till we get to null and stop
            for (int i = 0; i < curr.words.length && curr.children[i] != null; i++) { // traverse the children of our
                                                                                      // root
                if (curr.children[i] != null && commonWordFinder(curr.children[i], otherTree)) { // find another unique one
                    cWF = true;
                }
            }
        }
        } catch (NullPointerException e) {
            System.out.println("NULL pointer exception ");  
            cWF =  false;  
         }
         return cWF;
        

    }

    // unique word helper function
    private boolean findUniqueWords(TreeNode curr, GameTree otherTree) {
        // We null , return false MORE OR LESS LIKE
        if (curr == null) {
            return false;
        }

        boolean uniqueF = false;// did we find a unique one

        for (int i = 0; i < curr.words.length && curr.words[i] != null; i++) {
            String word = curr.words[i];
            if (!otherTree.containsWord(word)) { // did we see a match in our other tree
                uniqueF = true;
                System.out.println(word + " "); // print uniqueWord and its
                                                // frequency
            }
        }

        // Do it for every other non null children of our initial TreeNode By Calllling
        // recursively Till we get to null and stop
        for (int i = 0; i < curr.words.length && curr.children[i] != null; i++) { // traverse the children of our root
            if (findUniqueWords(curr.children[i], otherTree)) { // find another unique one by going to the next child
                uniqueF = true;
            }
        }

        return uniqueF;

    }

    public void printTree() {
        //WAS NOT IMPLEMENTED
    }

    public void setFrequency(String word, int frequency) {
        if(!containsWord(word)){
           String errMsg = "Cannot Set Non existent word frequency";
           System.out.print(errMsg);
        }else{
        TreeNode curr = findNode(word); 
        if (curr != null) {
            for(int i = 0; i < curr.words.length;i++){
                if(curr.words[i] != null && curr.words[i].compareToIgnoreCase(word) == 0){
                    curr.frequencies[i] = frequency;
                }
            }
        }
       }
    }

    private TreeNode findNode(String word) {
        return findNoode(root, word);
    }

    private TreeNode findNoode(TreeNode curr, String word) {
        if (curr == null) {
            return null; // Empty return empty
        }
        // Check if the word matches any of the words in the current node
        for (int i = 0; i < curr.words.length; i++) {
            if (curr.words[i] != null && curr.words[i].equals(word)) {
                return curr; // Word is found in the current node
            }
        }

        // Determine the correct child to search
        if (word.compareTo(curr.words[0]) < 0) {
            // our Word is less than the first word go to the left child
            return findNoode(curr.children[0], word);
        } else if (curr.words[1] == null || word.compareTo(curr.words[1]) < 0) {
            // Word is less than the second child or there isnt a second child go to the
            // middle child
            return findNoode(curr.children[1], word);
        } else {
            // Word is greater than the second child go to the right child
            return findNoode(curr.children[2], word);
        }
    }

}

/*
 * 
 * private BSTNode root;
 * 
 * // Constructor to initialize an empty BSTree
 * public BSTtree() {
 * this.root = null; // Start with an empty tree
 * }
 * 
 * public void addWord(String word) {
 * BSTNode W = new BSTNode(word);
 * BSTNode curr = root;
 * BSTNode parent = null;
 * boolean inserted = false;
 * 
 * if (root == null) {
 * root = W;
 * inserted = true;
 * } else {
 * while (curr != null && !inserted) {
 * parent = curr;
 * int comp = word.compareToIgnoreCase(curr.word);
 * if (comp < 0) {
 * curr = curr.left;
 * } else if (comp > 0) {
 * curr = curr.right;
 * } else {
 * curr.frequency++;
 * inserted = true;
 * }
 * }
 * 
 * if (!inserted) {
 * if (word.compareToIgnoreCase(parent.word) < 0) {
 * parent.left = W;
 * } else {
 * parent.right = W;
 * }
 * }
 * }
 * }
 * 
 * public boolean containsWord(String word) {
 * boolean present = false; // Initialize our present word Checker
 * 
 * if (this.root == null) {
 * return present; // if list is empty do not bother
 * } else {
 * BSTNode current = this.root; // start our counter at current
 * while (current != null && !present) { // loop while we have not fallen off
 * the tree and we have not yet
 * // found our word
 * if (current.word.compareToIgnoreCase(word) == 0) {
 * present = true; // if word is found set our present to found
 * } else if (current.word.compareToIgnoreCase(word) < 0) {
 * current = current.right; // if our word is bigger go right
 * } else {
 * current = current.left; // if smaller go left
 * }
 * }
 * }
 * return present; // finally return present
 * }
 * 
 * private int freqHelper(String word) {
 * boolean present = false; // Initialize our present word Checker
 * 
 * //Basically contains but we return the words frequency this time
 * BSTNode current = this.root; // start our counter at current
 * while (current != null && !present) {
 * if (current.word.compareToIgnoreCase(word) == 0) {
 * present = true; // if word is found set our present to found
 * } else if (current.word.compareToIgnoreCase(word) < 0) {
 * current = current.right; // if our word is bigger go right
 * } else {
 * current = current.left; // if smaller go left
 * }
 * }
 * return current.frequency; // finally return word frequency
 * }
 * 
 * public int getFrequency(String word) {
 * int freq = 0; // word is absent as initial frequency
 * if (!containsWord(word)) {
 * return freq; // not present freuency zero
 * } else {
 * return freqHelper(word); // return our frequency
 * }
 * 
 * // return our frequency
 * }
 * 
 * public void print() {
 * 
 * if(this.root != null){
 * printLexographically(this.root);
 * }
 * }
 * 
 * private void printLexographically(BSTNode curr){
 * System.out.print("[");
 * if(curr == null){
 * System.out.println("");
 * return;
 * }
 * 
 * printLexographically(curr.left);
 * System.out.print(curr.word + "(" + curr.frequency + ")");
 * printLexographically(curr.right);
 * 
 * System.out.print("]");
 * }
 * public int height() {
 * return recursiveHeight(root); // implement height search recursively
 * }
 * 
 * private int recursiveHeight(BSTNode node) {
 * // Base Case empty tree so return -1 as height
 * if (node == null) {
 * return -1;
 * }
 * 
 * // Recursive case: calculate the height of the left and right trees
 * int lH = recursiveHeight(node.left); // Height of the left child
 * int rH = recursiveHeight(node.right); // Height of the right child
 * 
 * return 1 + Math.max(lH, rH); // if both are null , max would be -1 plus 1 to
 * cut it out and return 0 for just the root or one leaf node
 * }
 * 
 * public void compare(GameTree otherTree) {
 * // TODO Auto-generated method stub
 * throw new UnsupportedOperationException("Unimplemented method 'compare'");
 * }
 * 
 * public void printTree() {
 * if (this.root == null)
 * System.out.println("EMPTY GAME TREE");
 * else {
 * System.out.println("CURRENT STATE OF TREE");
 * System.out.println();
 * }
 * }
 * 
 * private int findMinimum(BSTNode curr) {
 * if (curr.left != null) {
 * return findMinimum(curr.left);
 * } else {
 * return curr.frequency;
 * }
 * }
 * 
 * private int findMax(BSTNode curr) {
 * if (curr.right != null) {
 * return findMax(curr.left);
 * } else {
 * return curr.frequency;
 * }
 * }
 * }
 */