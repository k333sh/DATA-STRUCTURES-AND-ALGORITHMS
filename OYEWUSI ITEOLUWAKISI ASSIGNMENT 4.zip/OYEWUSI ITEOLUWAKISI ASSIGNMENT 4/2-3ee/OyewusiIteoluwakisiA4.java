import java.util.Scanner;

public class OyewusiIteoluwakisiA4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt user for file names for the two players' trees
        System.out.print("Enter the filename for Player A's tree: ");
        String fileA = scanner.nextLine().trim();

        System.out.print("Enter the filename for Player B's tree: ");
        String fileB = scanner.nextLine().trim();

        // Initialize the game object
        Game game = new Game();

        try {
            // Set up the game
            game.playerA.setupGame(fileA, fileB);

            // Start the game and play it
            game.playerA.playGame();
        } catch (Exception e) {
            System.out.println("Error during game setup or play: " + e.getMessage());
        }

        scanner.close();
    }
}
