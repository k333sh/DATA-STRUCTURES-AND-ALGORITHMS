public class pract {
    public static void main(String[] args) {
        int[] frequencies = new int[6];
         System.out.println(frequencies.length);
    }
}
