public class BSTtree implements GameTree {

    private BSTNode root;

    // Constructor to initialize an empty BSTree
    public BSTtree() {
        this.root = null; // Start with an empty tree
    }

    public void addWord(String word) {
        BSTNode W = new BSTNode(word);
        BSTNode curr = root;
        BSTNode parent = null;
        boolean inserted = false;

        if (root == null) {
            root = W;
            inserted = true;
        } else {
            while (curr != null && !inserted) {
                parent = curr;
                int comp = word.compareTo(curr.word);
                if (comp < 0) {
                    curr = curr.left;
                } else if (comp > 0) {
                    curr = curr.right;
                } else {
                    curr.frequency++;
                    inserted = true;
                }
            }

            if (!inserted) {
                if (word.compareTo(parent.word) < 0) {
                    parent.left = W;
                } else {
                    parent.right = W;
                }
            }
        }
    }

    public boolean containsWord(String word) {
        boolean present = false; // Initialize our present word Checker

        if (this.root == null) {
            return present; // if list is empty do not bother
        } else {
            BSTNode current = this.root; // start our counter at current
            while (current != null && !present) { // loop while we have not fallen off the tree and we have not yet
                                                  // found our word
                if (current.word.compareTo(word) == 0) {
                    present = true; // if word is found set our present to found
                } else if (current.word.compareTo(word) < 0) {
                    current = current.right; // if our word is bigger go right
                } else {
                    current = current.left; // if smaller go left
                }
            }
        }
        return present; // finally return present
    }

    private int freqHelper(String word) {
        boolean present = false; // Initialize our present word Checker

        // Basically contains but we return the words frequency this time
        BSTNode current = this.root; // start our counter at current
        while (current != null && !present) {
            if (current.word.compareTo(word) == 0) {
                present = true; // if word is found set our present to found
            } else if (current.word.compareTo(word) < 0) {
                current = current.right; // if our word is bigger go right
            } else {
                current = current.left; // if smaller go left
            }
        }
        return current.frequency; // finally return word frequency
    }

    public int getFrequency(String word) {
        int freq = 0; // word is absent as initial frequency
        if (!containsWord(word)) {
            return freq; // not present freuency zero
        } else {
            return freqHelper(word); // return our frequency
        }

        // return our frequency
    }

    public void print() {

        if (this.root != null) {
            printLexographically(this.root);
        }
    }

    private void printLexographically(BSTNode curr) {
        if (curr == null) {
            return; // null exit out

        } else {

            // recursive implementation
            printLexographically(curr.left); // Go left
            System.out.print(curr.word + "(" + curr.frequency + ")");
            printLexographically(curr.right);// Go right

        }
    }

    public int height() {
        return recursiveHeight(root); // implement height search recursively
    }

    private int recursiveHeight(BSTNode node) {
        // Base Case empty tree so return no height
        if (node == null) {
            return -1;
        }

        // Recursive case: calculate the height of the left and right trees
        int lH = recursiveHeight(node.left); // Height of the left child
        int rH = recursiveHeight(node.right); // Height of the right child

        return 1 + Math.max(lH, rH); // if both are null , max would be -1 plus 1 to cut it out and return 0 for just
                                     // the root or one leaf node
    }

    public void compare(GameTree otherTree) {
        // First check if we can compare at all
        if (otherTree == null || otherTree.getClass() != this.getClass()) {
            System.out.println("Invalid comparison - null tree");
            return;
        } else {

            System.out.println("Comparing trees:");

            // Print common words
            System.out.print("Common words: ");
            printCommonWords(this.root, otherTree);
            System.out.println(); // Set line after common words

            // Print words unique to this tree
            System.out.print("Unique to first tree: ");
            printUniqueWords(this.root, otherTree);
            System.out.println(); // Set line after unique words
        }
    }

    private void printCommonWords(BSTNode curr, GameTree otherTree) {
        if (curr == null) {

        } else {
            // print common words recursively moving over to the left
            printCommonWords(curr.left, otherTree);

            // Check if current word exists in other tree
            if (otherTree.containsWord(curr.word)) {
                // print the frequency of each of the 2 words
                System.out.print(curr.word + "(" + curr.frequency + ":" + otherTree.getFrequency(curr.word) + ") ");
            }

            printCommonWords(curr.right, otherTree); // Process right subtree
        }
    }

    private void printUniqueWords(BSTNode curr, GameTree otherTree) {
        if (curr == null) {

        } else {

            // Recursively process left subtree
            printUniqueWords(curr.left, otherTree);

            // Check if current word is unique to this tree
            if (!otherTree.containsWord(curr.word)) {
                System.out.print(curr.word + "(" + curr.frequency + ") ");
            }

            printUniqueWords(curr.right, otherTree); // Process right subtree
        }
    }

    public void printTree() {
        if (this.root == null)
            System.out.println("EMPTY GAME TREE");
        else {
            System.out.println("CURRENT STATE OF TREE");
            System.out.println();
        }
    }

    private int findMinimum(BSTNode curr) {
        if (curr.left != null) {
            return findMinimum(curr.left);
        } else {
            return curr.frequency;
        }
    }

    private int findMax(BSTNode curr) {
        if (curr.right != null) {
            return findMax(curr.left);
        } else {
            return curr.frequency;
        }
    }

    public void setFrequency(String word, int freq) {

     /* If we are not in the tree dont bother
     
        Start at the root of the tree
      * If we are at the word we want 
        set frequency value 
        else go left or right whilst not null
      */
       if(!containsWord(word)){
         System.out.println("CANNOT set THIS");
       }else{

      BSTNode curr = root ;

      while (curr != null) {
        if(word.compareToIgnoreCase(word ) == 0){
            curr.frequency = freq;
        }else if(word.compareToIgnoreCase(word) < 0){
           curr = curr.right;
        }else{
           curr = curr.left;
        }
      }
     }
    }
}
