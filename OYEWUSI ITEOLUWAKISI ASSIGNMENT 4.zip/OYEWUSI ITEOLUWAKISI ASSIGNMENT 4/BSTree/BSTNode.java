public class BSTNode {

    String word;
    int frequency;
    BSTNode left;
    BSTNode right;

    public BSTNode(String word) {
        this.word = word.toLowerCase();
        this.frequency = 1;
        this.left = null;
        this.right = null;
    }

}
