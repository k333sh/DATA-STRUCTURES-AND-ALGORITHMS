public class TestCompare {
	public static void main(String[] args) {
		// Can be done with BST by switching tree types
        GameTree tree = new BSTtree();

        System.out.println("===== Testing with TwoThreeTree =====");
        testCompare(tree);
	}

	public static void testCompare(GameTree tree) {
        tree.addWord("apple");
        tree.addWord("banana");
        tree.addWord("apple"); 
        tree.addWord("cherry");

        GameTree tree2 = new BSTtree();
        tree2.addWord("apple");
        tree2.addWord("banana");
        tree2.addWord("durian"); 
        tree2.addWord("cherry");
        System.out.println("--- Test: compare() Like Data Types ---");
        System.out.println("Expected Common Words: [apple, banana, cherry]");
        System.out.println("Expected Unique Words to Curr Tree: []");
        System.out.println("Expected Unique Words to Other Tree: [durian]");
		System.out.println("---");
        tree.compare(tree2);

        System.out.println("--- Test: compare() Different Data Types ---");
        System.out.println("Expected: The otherTree is not an instance of TwoThreeTree.");
		System.out.println("---");        
        GameTree tree3 = new BSTtree();
        tree.compare(tree3);        

    }
}