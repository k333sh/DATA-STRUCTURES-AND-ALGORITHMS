import java.io.File;
import java.util.Scanner;

public class WeightedGraph {
    int vertices = 0;
    int[][] adjMatrix;

    public WeightedGraph(int vertexes) {
        this.vertices = vertexes;
        this.adjMatrix = new int[vertexes][vertexes];

        for (int i = 0; i < vertexes; i++) {
            for (int j = 0; j < vertexes; j++) {
                adjMatrix[i][j] = 0;
            }
        }
    }

    public WeightedGraph(String fileName) {
        try (Scanner scanner = new Scanner(new File(fileName))) {
            if (scanner.hasNextLine()) {
                int vertexes = scanner.nextInt();
                this.vertices = vertexes;
                this.adjMatrix = new int[vertexes][vertexes];

                for (int i = 0; i < vertexes; i++) {
                    for (int j = 0; j < vertexes; j++) {
                        adjMatrix[i][j] = 0;
                    }
                }
            }

          while(scanner.hasNextLine ()){
            String line = scanner.nextLine().trim();

            String[] parsed = line.split(" ");
            if(parsed.length == 3){
             int vertOne = Integer.parseInt(parsed[0]);
             int vertTwo = Integer.parseInt(parsed[1]);
             int weight = Integer.parseInt(parsed[2]);

             adjMatrix[vertOne][vertTwo] = weight;
             adjMatrix[vertTwo][vertOne] = weight; //undirected graph 

            }

           
          }  

        } catch (Exception e) {
          System.err.println("ERROR READING FILE " + e.getMessage());
        }
    }





    

}
