public class MST {

   public static void main(String[] args) {
     
      String filename = args[0];
      WeightedGraph graph = new WeightedGraph(filename);
      MST mst = new MST(graph);
      mst.findMinSpanningTree();
   }

   private WeightedGraph graph; 

   public MST(WeightedGraph graph) {
      this.graph = graph;
   }

   public void findMinSpanningTree() {
      int n = graph.adjMatrix.length; // Number of vertices
      boolean[] visited = new boolean[n]; // Track visited vertices
      MinPQWeightedEdge pq = new MinPQWeightedEdge(); // Min-pq for edges
      int point = 0; // Start with vertex 0
      visited[point] = true; // Mark it as visited
      int totalWeight = 0; // Track total weight of the MST

      // Add all edges linked to our starting point to the PQ
      for (int j = 0; j < n; j++) {
         if (graph.adjMatrix[point][j] > 0) { // If edge exists
            pq.insert(new WeightedEdge(point, j, graph.adjMatrix[point][j])); // insert it
         }
      }

      // Process edges until the priority queue is empty or all vertices are visited
      while (!pq.isEmpty()) {
         WeightedEdge edge = pq.retrieveMin(); // Get the smallest edge
         int nextVertex = edge.vertixDuos; // Get the connected vertex to our first vertex

         // If this vertex is not visited
         if (!visited[nextVertex]) {

            // Add this edge to the MST
            totalWeight += edge.Eweight; // Add edge weight to total weight
            visited[nextVertex] = true; // Mark the vertex as visited

            //print each edge with its name alongside its weight
            System.out.println("EDGE {" + edge.vertixUno + "," + edge.vertixDuos + "} (" + edge.Eweight + ")");

            // Update the point to the newly added vertex
            point = nextVertex;

            // Restart process ychecking all edges bteween our new vertex and the unchecked
            // other vertexes
            for (int j = 0; j < n; j++) {
               if (!visited[j] && graph.adjMatrix[point][j] > 0) {
                  pq.insert(new WeightedEdge(point, j, graph.adjMatrix[point][j])); // if theres an edge add to our  queue
               }
            }
         }
      }

      // print our MST

      // Print total weight of MST
      System.out.println("Total weight of the MST: " + totalWeight);

   }

}
