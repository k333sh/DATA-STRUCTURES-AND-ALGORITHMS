public interface EdgeManager {
    public void insert(WeightedEdge otherEdge);

    public WeightedEdge retrieveMin();

    public boolean isEmpty();

    public void print();


}
