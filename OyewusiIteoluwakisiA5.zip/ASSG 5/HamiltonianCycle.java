public class HamiltonianCycle {
  private WeightedGraph graph;
  private int[] bestHCycle; // keep track of vertices in the best cycle
  private int minWeight = Integer.MAX_VALUE; // track smallest weight so for comparison start at largest value
  private MinPQWeightedEdge pq;

  public HamiltonianCycle(WeightedGraph graph) {
    this.graph = graph;
  }

  public void findHamiltonianCycle(){

  }

}
