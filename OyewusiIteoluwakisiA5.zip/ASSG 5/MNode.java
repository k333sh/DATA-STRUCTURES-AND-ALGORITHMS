public class MNode {
    public int data;
    public MNode next;

    public MNode(int data){
     this.data = data;
     this.next = null;
    }
}
