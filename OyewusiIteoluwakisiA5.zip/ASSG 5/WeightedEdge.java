public class WeightedEdge implements Comparable<WeightedEdge>{
    int vertixUno = 0;//first connected vertex
    int vertixDuos = 0;//second connected verrtex
    int Eweight = 0; //edge weight

    public WeightedEdge(int a, int b, int c){
     this.vertixUno = a;
     this.vertixDuos = b;
     this.Eweight = c;
    }

   
    public int compareTo(WeightedEdge otherEdge) {
     return Integer.compare(this.Eweight, otherEdge.Eweight); //compare edge weight using integer compareTo 
    }

    public String toString() {
        return String.format("Edge (%d,%d), Weight --> %d" , vertixUno , vertixDuos ,Eweight);
    }



}
