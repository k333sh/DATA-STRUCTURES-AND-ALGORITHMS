public class MinPQWeightedEdge implements EdgeManager {

    private WeightedEdge[] heap;
    private int size;// no of elements in the array
    private int capacity; // current array capacity

    public MinPQWeightedEdge() {
        this.capacity = 20;
        this.heap = new WeightedEdge[capacity];
        this.size = 0;
    }

    public void insert(WeightedEdge otherEdge) {
        if (size == capacity) {
            WeightedEdge[] newArray = new WeightedEdge[2 * capacity];
            for (int i = 0; i < size; i++) {
                newArray[i] = heap[i];
            }
            this.heap = newArray;
            this.capacity = 2 * capacity;

        }

        heap[size] = otherEdge;
        int current = size;
        size++;

        boolean heapified = false;
        // traverse till we bubble to the top
        while (current > 0 && !heapified) {

            int parent = ((current - 1) / 2);

            // Minimum priority que , so root is the smallest
            if (heap[current].compareTo(heap[parent]) < 0){
                swap(current, parent);
                current = parent;
            } else {
                heapified = true;
            }
        }

    }

    private void swap(int child, int parent) {
        WeightedEdge temp = this.heap[child];
        this.heap[child] = this.heap[parent];
        this.heap[parent] = temp;

    }

    public WeightedEdge retrieveMin() {
        WeightedEdge min = null;
        if (isEmpty()) {
            System.out.println("NO EDGES PRESENT");
        } else {
            min = heap[0];

            heap[0] = heap[size - 1];
            size = size - 1;
            int current = 0; //start at root then bubble down

            boolean sortedOut = false;
            // traverse till we bubble to the top

            while (current < size && !sortedOut) {

                int leftChild  = ((2 * current) + 1);
                int rightChild = ((2 * current) + 2);
                int rooot = current;

                // Minimum priority que , so root is the smallest
                
                if (leftChild < size && heap[leftChild].compareTo(heap[rooot]) < 0) {
                  rooot = leftChild;
                }
                
                if(rightChild < size && heap[rightChild].compareTo(heap[rooot]) < 0) {
                    rooot = rightChild;
                }
                

                if(rooot == current){
                  sortedOut = true;
                }
                swap(current, rooot);
                current = rooot;
            }

        }
        return min;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public void print() {
        if (isEmpty()) {
            System.out.println("");
        } else {
            System.out.println("Priority Queue Weights:");
            for (int i = 0; i < size; i++) {
                System.out.print(heap[i].Eweight + " ");
            }
            System.out.println(); 
        }
    }
}
