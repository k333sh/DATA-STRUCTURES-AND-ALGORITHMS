//MY STACK CREATED 
public class MStack {
    private MNode top;

    public void push(int data) {
        MNode newN = new MNode(data);
        newN.next = top;
        top = newN;
    }

    public int pop() {
        if (isEmpty()) {
            System.out.println("IT IS EMPTY");
        }
        int dataa = top.data;
        top = top.next;
        return dataa;
    }

    public int peek() {
        if (isEmpty()) {
            System.out.println("EMPTY NOTHING TO PEEK");
        }
        return top.data;
    }

    public boolean isEmpty() {
        return top == null;
    }

}
