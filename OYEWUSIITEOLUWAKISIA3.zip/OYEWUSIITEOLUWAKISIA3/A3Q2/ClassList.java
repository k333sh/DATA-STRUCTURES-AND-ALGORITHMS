/* OYEWUSI ITEOLUWAKISI
     * 7959523 
     * CLASSLIST HASHTABLE IMPLEMENTATION USED MY DOUBLY LINKED LIST AS WELL AS
     * MY SNODE AND STUDENT CLASS IPLEMENTATIONS
     * 
     * 
     * MAKE USE OF DUMMY AND DOUUBLY LINKED NODES TO TRAVERSE WITH EASE AND USE THIS ADT TO 
     * PERFORM EFFICIENT INSERT DELETE SEARCH OPERATIONS ON A LARGER SCALE   
     */

public class ClassList {
  private SNode top;
  private SNode header;
  private SNode trailer;

  public ClassList() {
    header = new SNode(new Student("", -1, "", ""));
    trailer = new SNode(new Student("", Integer.MAX_VALUE, "", ""));
    header.next = trailer;
    trailer.back = header;
    top = header;
  }

  public boolean contains(Student student) {
    SNode current = header.next;// current node starts at first real node

    // traverse list till we hit the trailer  or we pass the student
    while (current != trailer && current.data.compareTo(student) <= 0) {
      // if found return true
      if (current.data.compareTo(student) == 0) {
        return true;
      }
      current = current.next;
    }
    return false; // else false its not contained
  }

  public void enroll(Student student) {
    if (contains(student)) {
      return; // Take no action if student is already enrolled
    } else {
      SNode newNode = new SNode(student); // Initialize newNode to be inserted
      SNode current = Traverse(student); // Traverse the list

      // Insert newNode into the list
      newNode.next = current; // Set newNode.next to current
      newNode.back = current.back; // Set newNode.back to the previous node
      current.back.next = newNode; // Point the previous node's next to newNode
      current.back = newNode; // Update the current's back pointer to newNode
    }
  }

  public void unenroll(Student student) {
    if (!contains(student) || (header.next == trailer)) {
      return;
    } else {
      SNode current = header.next;// current node starts at first real node
      // traverse list till we hit the trailer or get to the node that will be
      // unenrolled
      while (current.next != trailer && current.data.compareTo(student) < 0) {
        current = current.next;
      }
      current.back.next = current.next; // point previous node to the node afteer deleted node
      current.next.back = current.back; // point next back to previous from delete
    }

  }

  public void enrollAll(ClassList otherList) {
    SNode Current = otherList.header.next; // points to the first real node of the other list 

    while (Current != otherList.trailer) {
      enroll(Current.data); //loop through all the lists and enroll each element in the other list into our list
      Current = Current.next; //traverse
    }
  }

  public void unenrollAll(ClassList otherList) {
    SNode Current = otherList.header.next; // points to the first real node of the other list 

    while (Current != otherList.trailer) {
      unenroll(Current.data); //remove eeach 
      Current = Current.next; //traverse
    }

  }

  public ClassList duplicate() {
    //create a new classlist
    ClassList returnedList = new ClassList();
    returnedList.enrollAll(this); //enroll all componenets of my list into this new one 

    return returnedList; // return that list
  }

  public ClassList alsoEnrolledIn(ClassList otherList) {
    SNode Current = otherList.header.next; // points to the first real node
    ClassList enrolledIn = new ClassList(); //new list created

    //go down till traileer
    while (Current != otherList.trailer) {
      if (contains(Current.data)) { //if there is a match enrolll it
        enrolledIn.enroll(Current.data);
      }
      Current = Current.next; // move 
    }
    return enrolledIn; //return finished classlist
  }

  public ClassList notAlsoEnrolledIn(ClassList otherList) {
    SNode Current = otherList.header.next; // points to the first real node
    ClassList NOTenrolledIn = new ClassList(); 
    while (Current != otherList.trailer) {
      if (!contains(Current.data)) {
        NOTenrolledIn.enroll(Current.data); //not a match add to this new list
      }
      Current = Current.next; //move
    }
    return NOTenrolledIn; //return new list 
  }

  public void print() {
    if (header.next == trailer) { // if empty
      System.out.println("THERE ARE NO CONTENTS OF THE CLASSLIST"); //let user know
    } else {
      SNode Current = header.next; // start with the first real node
 
      //while we are still within lists elements
      while (Current != trailer) {
        System.out.println("-" + Current.data + ""); //print content
        Current = Current.next; //move
      }
    }
  }

  private SNode Traverse(Student student) {
    SNode current = header.next; //strt at the first real node 
   //traverse till greater
    while (current != trailer && current.data.compareTo(student) <= 0) {
      current = current.next; //traverse 
    }
    return current;
  }

}
