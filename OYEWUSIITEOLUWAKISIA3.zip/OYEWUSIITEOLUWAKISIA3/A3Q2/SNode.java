public class SNode {
   //Node class (customized as SNode )
   //Utiizing Doubly Linked List
    public Student data ; //student data
    public SNode next ;  //next pointer
    public SNode back;
     
    //node constructor
    SNode(Student student){
     this.data = student; 
     this.back = null;
     this.next = null;
    }
  

}
