

public class Student implements Comparable<Student>{
    //Indicite constructor variables
    String username;
    String firstName;
    String Lastname;
    int id;
    

   public Student (String username, int id, String firstname, String lastname ){
      this.Lastname = lastname;
      this.firstName = firstname;
      this.username = username;
      this.id = id;
   }

    public int compareTo( Student OtherSTudent) {
        return this.username.compareToIgnoreCase(OtherSTudent.getUsername());
    }


    public String getUsername() { 
        return this.username;
    }
    
    public String toString(){
        return ("STUDENT "+ this.id + ": " + " The username is : "+this.username + " The firstName is : "+this.firstName + " The LastName is : "+this.Lastname);
    }

}



