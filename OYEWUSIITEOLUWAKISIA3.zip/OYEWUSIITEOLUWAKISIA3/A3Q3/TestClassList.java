import java.util.ArrayList;
import java.util.List;


public class TestClassList {
    public static void main(String[] args) {
        ClassList classList = new ClassList();

        // Test case 1: Enroll a student
        Student student1 = new Student("jdoe", 1, "John", "Doe");
        classList.enroll(student1);
        System.out.println("Test 1 - Enroll student: ");
        classList.print(); // Should print the student list containing John Doe

        // Test case 2: Enroll another student
        Student student2 = new Student("asmith", 2, "Alice", "Smith");
        classList.enroll(student2);
        System.out.println("\nTest 2 - Enroll another student: ");
        classList.print(); // Should contain John Doe and Alice Smith

        // Test case 3: Attempt to enroll a duplicate student
        Student duplicateStudent = new Student("jdoe", 1, "John", "Doe");
        classList.enroll(duplicateStudent); // Should not change the list
        System.out.println("\nTest 3 - Enroll duplicate student: ");
        classList.print(); // Should still contain only John Doe and Alice Smith

        // Test case 4: Unenroll a student
        classList.unenroll(student1);
        System.out.println("\nTest 4 - Unenroll a student: ");
        classList.print(); // Should only contain Alice Smith

        // Test case 5: Unenroll a non-existent student
        classList.unenroll(student1); // Should not change the list
        System.out.println("\nTest 5 - Unenroll non-existent student: ");
        classList.print(); // Should still only contain Alice Smith

        // Test case 6: Enroll multiple students
        Student student3 = new Student("bsmith", 3, "Bob", "Smith");
        Student student4 = new Student("cjohnson", 4, "Charlie", "Johnson");
        classList.enroll(student3);
        classList.enroll(student4);
        System.out.println("\nTest 6 - Enroll multiple students: ");
        classList.print(); // Should print all enrolled students

        // Test case 7: Duplicate enrollment check
        classList.enroll(student3); // Should not enroll again
        System.out.println("\nTest 7 - Duplicate enrollment check: ");
        classList.print(); // Should still show each student only once

        // Test case 8: Enroll students with special characters
        Student student5 = new Student("alice@home.com", 5, "Alice", "Johnson");
        classList.enroll(student5);
        System.out.println("\nTest 8 - Enroll student with special characters: ");
        classList.print(); // Should include all students including Alice with special characters

        // Test case 9: Check if the list contains a specific student
        System.out.println("\nTest 9 - Contains student 'asmith': " + classList.contains(student2)); // Should return true
        System.out.println("Test 9 - Contains student 'jdoe': " + classList.contains(student1)); // Should return false

        // Test case 10: Duplicate enrollment across two ClassList instances
        ClassList anotherClassList = new ClassList();
        anotherClassList.enroll(student1);
        anotherClassList.enroll(student3);
        System.out.println("\nTest 10 - Another ClassList after enrolling John and Bob: ");
        anotherClassList.print(); // Should contain John Doe and Bob Smith

        // Test case 11: Enroll all from another ClassList
        classList.enrollAll(anotherClassList);
        System.out.println("\nTest 11 - Enroll all from another ClassList: ");
        classList.print(); // Should include all students from both ClassList instances
    }
}

/* 
 
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class TestClassList {
    public static void main(String[] args) {
        // Define the filename directly in the code
        String filename = "commands.txt"; // You can change this to your desired filename
        ClassList[] classLists = null;

        try {
            Scanner scanner = new Scanner(new File(filename));
            // Read the number of ClassLists
            if (scanner.hasNextLine()) {
                int numClassLists = Integer.parseInt(scanner.nextLine());
                classLists = new ClassList[numClassLists];

                // Initialize ClassLists
                for (int i = 0; i < numClassLists; i++) {
                    classLists[i] = new ClassList();
                }
            }

            // Read and execute commands from the file
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split(" ");

                if (parts[0].equals("C")) { // Create ClassList
                    // Implement file reading logic
                    String studentFile = parts[1];
                    int index = Integer.parseInt(parts[2]);
                    // Assume a method loadStudentsFromFile exists to load students
                    loadStudentsFromFile(studentFile, classLists[index]);
                } else if (parts[0].equals("P")) { // Print ClassList
                    int index = Integer.parseInt(parts[1]);
                    classLists[index].print();
                } else if (parts[0].equals("D")) { // Duplicate ClassList
                    int fromIndex = Integer.parseInt(parts[1]);
                    int toIndex = Integer.parseInt(parts[2]);
                    classLists[toIndex] = classLists[fromIndex].duplicate();
                } else if (parts[0].equals("E")) { // Enroll all students from one ClassList to another
                    int fromIndex = Integer.parseInt(parts[1]);
                    int toIndex = Integer.parseInt(parts[2]);
                    classLists[toIndex].enrollAll(classLists[fromIndex]);
                } else if (parts[0].equals("U")) { // Unenroll all students from one ClassList
                    int fromIndex = Integer.parseInt(parts[1]);
                    int toIndex = Integer.parseInt(parts[2]);
                    classLists[fromIndex].unenrollAll(classLists[toIndex]);
                } else if (parts[0].equals("A")) { // Also enrolled in
                    int list1Index = Integer.parseInt(parts[1]);
                    int list2Index = Integer.parseInt(parts[2]);
                    int targetIndex = Integer.parseInt(parts[3]);
                    classLists[targetIndex] = classLists[list1Index].alsoEnrolledIn(classLists[list2Index]);
                } else if (parts[0].equals("N")) { // Not also enrolled in
                    int list1Index = Integer.parseInt(parts[1]);
                    int list2Index = Integer.parseInt(parts[2]);
                    int targetIndex = Integer.parseInt(parts[3]);
                    classLists[targetIndex] = classLists[list1Index].notAlsoEnrolledIn(classLists[list2Index]);
                }
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + filename); //print out error case
        } 
    }

    // Method to load students from a specified file into a ClassList
    private static void loadStudentsFromFile(String filename, ClassList classList) {
        try {
            Scanner fileScanner = new Scanner(new File(filename));
            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                String[] parts = line.split(",");
                if (parts.length == 4) { // Check if all necessary parts are present
                    String username = parts[0];
                    int id = Integer.parseInt(parts[1]);
                    String firstName = parts[2];
                    String lastName = parts[3];
                    classList.enroll(new Student(username, id, firstName, lastName));
                }
            }
            fileScanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + filename);
        } catch (NumberFormatException e) {
            System.out.println("Invalid number format in student file.");
        }
    }
}
*/