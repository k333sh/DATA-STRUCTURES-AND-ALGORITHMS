public class SNode {
    Student data; //inputed node data
    SNode next; //forward pointer
    SNode back; //back poinyter  
    // for doubly linked list

    public SNode(Student data) {
        this.data = data;
        //initialize my back and next pointers
        this.next = null;
        this.back = null;
    }
}