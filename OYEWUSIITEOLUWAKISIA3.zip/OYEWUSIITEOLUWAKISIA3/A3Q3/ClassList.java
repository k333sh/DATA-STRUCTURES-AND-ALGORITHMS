public class ClassList {
    /* OYEWUSI ITEOLUWAKISI
     * 7959523 
     * CLASSLIST HASHTABLE IMPLEMENTATION USED MY DOUBLY LINKED LIST AS WELL AS
     * MY SNODE AND STUDENT CLASS IPLEMENTATIONS  
     */
    
    
    /*
     * Initialize our classlist tables
     * create table array
     * size being the number of buckets occupied
     * declare my header and trailer nodes for my doubly linked list
     */

    private SNode[] table;
    private int size;
    private final int DEFAULT_CAPACITY = 500;
    private SNode header;
    private SNode trailer;

    public ClassList() {
        // Initialize hash table
        table = new SNode[DEFAULT_CAPACITY];// cap our hash table at default capacity
        size = 0;

        // Initialize our header and trailer
        header = new SNode(null); 
        trailer = new SNode(null);
        header.next = trailer;
        trailer.back = header;

        // Initialize each bucket with a sentinel node
        for (int i = 0; i < DEFAULT_CAPACITY; i++) {
            table[i] = new SNode(null); // give each bucket in our array a set starter nodes
        }
    }

    private int hashFunc(String username) {
        if (username == null || username.isEmpty()) {
            return 0;
        }

        int hV = 0;
        int prime = 7; // Better prime number for hashing
        int M = username.length();

        // Looop through our username and create a hash for each character within then
        // add
        for (char c : username.toCharArray()) {
            hV = (AlphaConv(c) * (int) Math.pow(prime, M - (1 + (username.indexOf(c))))) % table.length; // use  Polynomial hashing function
        }
        return hV;
    }
 

    //alphabet to alphabet key creator 
    private int AlphaConv(char c) {
        if (c >= 'A' && c <= 'Z') {
            return c - 'A' + 1;
        } else if (c >= 'a' && c <= 'z') {
            return c - 'a' + 1;
        }
        return 0;
    }

    public boolean contains(Student student) {
        // if the student isnt valid or size (amount of enrolled students) is 0 , no students in our table
        if (student == null || size == 0) {
            return false; // safe to say nothing is present within
        }

        int index = hashFunc(student.getUsername());// get index to search through the list off
        SNode current = table[index].next; // start search at current

        // while current doesnt point to null or is not greater than input username
        while (current != null && current.data.compareTo(student) <= 0) {
            // use our compareTo to check equality
            if (current.data != null && current.data.compareTo(student) == 0) {
                return true;
            }
            current = current.next; //traverse
        }
        return false; //return false if nothing was found
    }

    public void enroll(Student student) {
        //if student is enrollable 
        if(isNotEnrollable(student))
        {
            System.out.println("INVALID STUDEN CANT BE ENROLLED");
            return; //step out
        }
         //start at hashed bucket
        int index = hashFunc(student.getUsername());
        SNode newNode = new SNode(student); //create inserted node

        // Insert at the beginning of the list after header 
        newNode.next = table[index].next;
        //if start point does not point to null 
        if (table[index].next != null) {
            table[index].next.back = newNode; //we attach the back of the next node to new node to insert it 
            newNode.next = table[index].next;  //complete the link up  
        }
        newNode.back = table[index]; //point newnode backwards  to the header
        table[index].next = newNode; //point header forward to node
        size++; //add to the enrollment count
    }

    public void unenroll(Student student) {
         // if the student isnt valid or size (amount of enrolled students) is 0 , no students in our table
        if (student == null || size == 0) {
            return; //step out
        }

        //get index
        int index = hashFunc(student.getUsername());
        SNode current = table[index].next; //start at real node 
        
        //while wwe are below not passed the possible spot for our student 
        while (current != null && current.data.compareTo(student) <= 0) {
            if (current.data != null && current.data.equals(student)) {
                // Remove the node 
                current.back.next = current.next;
                if (current.next != null) {
                    current.next.back = current.back;//poiny back across current and remove it from the link 
                }
                size--; //decrrement size 
                return;
            }
            current = current.next; //traverse
        }
    }

    public void enrollAll(ClassList otherList) {
        if (otherList == null) {
            return;
        }//dont implement if other list is empty 

        //loop through other list , then l
        for (int i = 0; i < otherList.table.length; i++) {
            SNode current = otherList.table[i].next; //loop through each bucket 
            while (current != null) { //till end of list 
                if (current.data != null) { 
                    enroll(current.data);//enroll each piece of data  in each bucket 
                }
                current = current.next; //traverse
            }
        }
    }

    public void unenrollAll(ClassList otherList) {
        if (otherList == null) {
            return; //is the list useable
        }

        

        for (int i = 0; i < otherList.table.length; i++) { //traverse the same as enrollALL
            SNode current = otherList.table[i].next;
            while (current != null) {
                if (current.data != null) {
                    unenroll(current.data); //unenroll this time
                }
                current = current.next; //traverse
            }
        }
    }

    public ClassList duplicate() {
        ClassList dupe = new ClassList(); //new classList
        //loop till we reach end of table
        for (int i = 0; i < table.length; i++) {
            SNode current = table[i].next; //start at the first real node in each bucket
            while (current != null) {
                if (current.data != null) {
                    dupe.enroll(current.data); //enroll if the data is valid 
                }
                current = current.next; //traverse
            }
        }
        return dupe; //return list 
    }

    public ClassList alsoEnrolledIn(ClassList otherList) {
        if (otherList == null) {
            return new ClassList(); //rturn empty classlist if other list is empty oimplying no matches among the two classLists
        }

        ClassList result = new ClassList(); //new list
        //loop through the entire other list
        for (int i = 0; i < otherList.table.length; i++) {
            SNode current = otherList.table[i].next; //start from first otherlist node
            while (current != null) {
                if (current.data != null && this.contains(current.data)) {
                    result.enroll(current.data); //if there is a match while traversing enroll it 
                }
                current = current.next;//move 
            }
        }
        return result;
    }
    

    public ClassList notAlsoEnrolledIn(ClassList otherList) {
        if (otherList == null) {
            return this.duplicate(); //this time duplicate in case of emptyness
        }

        ClassList notENr= new ClassList(); //new list to keep track of variables that shouldnt be enrolled 
        for (int i = 0; i < table.length; i++) {
            SNode current = table[i].next;//declare new node current
            //loop through each bucket list
            while (current != null) {
                if (current.data != null && !otherList.contains(current.data)) {
                    notENr.enroll(current.data); //if there is a match and current data isnt nothing  enroll in our classlist 
                }
                current = current.next; //traverse
            }
        }
        return notENr; //return
    }

    public void print() {
        if (size == 0) {
            System.out.println("THERE ARE NO CONTENTS OF THE CLASSLIST"); //nothing to print 
            return;//step out 
        }

        for (int i = 0; i < table.length; i++) {
            SNode current = table[i].next; //loop through each bucket start at current for each bucket list 
            if (current != null) {
                System.out.print("BUCKET " + i + ": "); //print out bucket number first 
                while (current != null) {
                    if (current.data != null) {
                        System.out.println(":----" + current.data); //for each node in list pint it
                    }
                    current = current.next; //move on 
                }
                System.out.println();
            }
        }
    }

    public boolean isNotEnrollable(Student student){
        if (student == null || contains(student)){ //if student is nothing or tables and no student is in or contained
          return true;
        }
        return false;// else return false 
    }

    

}